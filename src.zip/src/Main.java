public class Main {
    public static void main(String[] args) {
        Wycieczka[] wycieczki = getWycieczki();

        Klient[] klienci = getKlientow();

        WykupionaWycieczka[] wykupioneWycieczki = getWykupioneWycieczki(wycieczki, klienci);

        System.out.println("|| Ilosc wykupionych wycieczek: "+ WykupionaWycieczka.iloscWycieczek + "\n\n");

        for(Wycieczka w: wycieczki)
            System.out.println(w + "\n");

        System.out.println("\n");


        Klient klient = null;
        int max = 0;
        for(Klient k: klienci)
        {
            if(k.wycieczki.length == 0)
                System.out.println(k);
                else{
                    System.out.println(k + "\n" +  "|| Wycieczki: ||");
                    k.getWycieczka();
                    System.out.println("|| Pełna kwota wycieczek: " + k.getCena() + " zł || \n");
                        if(k.getCena() > max)
                        {
                            max = k.getCena();
                            klient = k;
                        }
                    }



        }
            if(klient == null)
                {
                    System.out.println("ERROR");
                }
            else
            System.out.println("|| Najwięcej zapłacił: " + klient.imie + " | Suma: " + max + " zł ||");

        System.out.println("\n");

        String ba ="", sp = "", du = "", no = "", rz = "", pa = "", wa = "", lo="";

        int b = 0, s = 0, d = 0, n = 0, r = 0, p = 0, w = 0, l = 0, o = 0;

        for (Klient value : klienci) {
            for (Wycieczka wycieczka : value.wycieczki) {
                switch (wycieczka.cel) {
                    case "Barcelona" ->{
                        b++;
                        ba += "ba";
                    }
                    case "Dubaj" ->{
                        d++;
                        du += "du";
                    }
                    case "Nowy Jork" ->{
                        n++;
                        no += "no";
                    }
                    case "Rzym" ->{
                        r++;
                        rz += "rz";
                    }
                    case "Paryż" ->{
                        p++;
                        pa += "pa";
                    }
                    case "Warszawa" ->{
                        w++;
                        wa += "wa";
                    }
                    case "Londyn" ->{
                        l++;
                        lo += "lo";
                    }
                }
            }
        }

        int[] array = {b, s, d, n, r, p, w, l, a};
        String[] array2 = {ba, sp, du, no, rz, pa, wa};

        int temp;
        boolean swapped;
        for (int i = 0; i < array.length - 1; i++) {
            swapped = false;
            for (int j = 0; j < array.length - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped)
                break;
        }

        String temp2;
        boolean swapped2;
        for (int i = 0; i < array.length - 1; i++) {
            swapped = false;
            for (int j = 0; j < array.length - i - 1; j++) {
                if (array2[j].length() >  array2[j + 1].length()) {
                    temp2 = array2[j];
                    array2[j] = array2[j + 1];
                    array2[j + 1] = temp2;
                    swapped = true;
                }
            }
            if (!swapped)
                break;
        }


        for(int i = array.length - 1; i >= 0; --i)
        {
            if(array2[i].contains("b"))
                returnText("➝ Barcelona", array[i]);
            else if(array2[i].contains("s"))
                returnText("➝ Split", array[i]);
            else if(array2[i].contains("d"))
                returnText("➝ Dubaj", array[i]);
            else if(array2[i].contains("n"))
                returnText("➝ Nowy Jork", array[i]);
            else if(array2[i].contains("l"))
                returnText("➝ Londyn", array[i]);
            else if(array2[i].contains("p"))
                returnText("➝ Paryż", array[i]);
            else if(array2[i].contains("w"))
                returnText("➝ Warszawa", array[i]);
        }

    }

    private static void returnText(String kraj, int ilosc)
    {
        System.out.println(kraj + ": " + ilosc);
    }

    private static Wycieczka[] addWycieczki(Klient k, Wycieczka w)
    {
        Wycieczka[] newArray = new Wycieczka[k.wycieczki.length + 1];
        if(k.wycieczki.length == 0)
        {
            newArray[k.wycieczki.length] = w;
            return newArray;
        }

        for(int i = 0; i < k.wycieczki.length; ++i)
            newArray[i] = k.wycieczki[i];

        newArray[k.wycieczki.length] = w;

        return newArray;
    }
    private static Wycieczka[] getWycieczki() {
        Wycieczka[] wycieczki = {new Wycieczka(new Data(12, 6, 2024), new Data(26, 6, 2024), "Barcelona", "Wycieczka do malowniczej Barcelony", 9000, 30, new Czas(12, 45), new Czas(12, 12))};

        wycieczki = add(wycieczki, wycieczki.length, new Wycieczka(new Data(15, 1, 2023), new Data(28, 1, 2023), "Split", "Wycieczka do chorwackiego Splitu", 5000, 45, new Czas(8, 0), new Czas(10, 0)));

        wycieczki = add(wycieczki, wycieczki.length, new Wycieczka(new Data(29, 9, 2023), new Data(6, 10, 2023), "Dubaj", "Wyjazd do Dubaju", 14000, 45, new Czas(6, 30), new Czas(22, 0)));

        wycieczki = add(wycieczki, wycieczki.length, new Wycieczka(new Data(12, 7, 2023), new Data(20, 7, 2023), "Nowy Jork", "Wyjazd do ogromnego Nowego Jorku", 15000, 90, new Czas(7, 0), new Czas(0, 0)));

        wycieczki = add(wycieczki, wycieczki.length, new Wycieczka(new Data(10, 8, 2023), new Data(17, 8, 2023), "Rzym", "Wyjazd do Rzymu", 16000, 25, new Czas(8, 0), new Czas(12, 0)));

        wycieczki = add(wycieczki, wycieczki.length, new Wycieczka(new Data(1, 6, 2022), new Data(8, 6, 2022), "Paryż", "Wycieczka romantyczna do Paryża", 18000, 55, new Czas(14, 0), new Czas(19, 0)));

        wycieczki = add(wycieczki, wycieczki.length, new Wycieczka(new Data(15, 7, 2023), new Data(25, 7, 2023), "Warszawa", "Wycieczka do stolicy Polski - Warszawy", 17500, 25, new Czas(6, 45), new Czas(6, 0)));


        return wycieczki;
    }

    private static Klient[] getKlientow() {
        Klient[] klienci = {new Klient("Jan", "Dabrowski", 17, "Sosnowiec")};

        klienci = add(klienci, klienci.length, new Klient("Mariusz", "Radziwil", 25, "Wiesiolka"));

        klienci = add(klienci, klienci.length, new Klient("Marcel", "Szczecinski", 33, "Wroclaw"));

        klienci = add(klienci, klienci.length, new Klient("Maurycy", "Wolski", 19, "Opole"));

        klienci = add(klienci, klienci.length, new Klient("Daniel", "Czechowski", 30, "Katowice"));

        klienci = add(klienci, klienci.length, new Klient("Tymoteusz", "Kmiecik", 23, "Sandomierz"));

        klienci = add(klienci, klienci.length, new Klient("Szymon", "Macierewicz", 36, "Myslowice"));

        klienci = add(klienci, klienci.length, new Klient("Paweł", "Ociepka", 18, "Zawiercie"));

        klienci = add(klienci, klienci.length, new Klient("Kuba", "Kowalski", 45, "Będzin"));

        klienci = add(klienci, klienci.length, new Klient("Klaudia", "Nowak", 19, "Bedzin"));

        return klienci;
    }
    private static WykupionaWycieczka[] getWykupioneWycieczki(Wycieczka[] wycieczki, Klient[] klienci)
    {

        WykupionaWycieczka[] wykupioneWycieczki = {};
        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[0].czas_wyjazd, wycieczki[0].czas_przyjazd, wycieczki[0].data_wyjazd, wycieczki[0].data_przyjazd, wycieczki[0].cel, wycieczki[0].cel, wycieczki[0].cena, new Data(24, 1, 2023), klienci[0]));

        klienci[0].wycieczki = addWycieczki(klienci[0], wycieczki[0]);

        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[1].czas_wyjazd, wycieczki[1].czas_przyjazd, wycieczki[1].data_wyjazd, wycieczki[1].data_przyjazd, wycieczki[1].cel, wycieczki[1].opis, wycieczki[1].cena, new Data(13, 1, 2023), klienci[1]));

        klienci[1].wycieczki = addWycieczki(klienci[1], wycieczki[1]);

        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[2].czas_wyjazd, wycieczki[2].czas_przyjazd, wycieczki[2].data_wyjazd, wycieczki[2].data_przyjazd, wycieczki[2].cel, wycieczki[2].opis, wycieczki[2].cena, new Data(13, 6, 2023), klienci[2]));

        klienci[2].wycieczki = addWycieczki(klienci[2], wycieczki[2]);

        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[3].czas_wyjazd, wycieczki[3].czas_przyjazd, wycieczki[3].data_wyjazd, wycieczki[3].data_przyjazd, wycieczki[3].cel, wycieczki[3].opis, wycieczki[3].cena, new Data(10, 6, 2023), klienci[3]));

        klienci[3].wycieczki = addWycieczki(klienci[3], wycieczki[3]);

        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[4].czas_wyjazd, wycieczki[4].czas_przyjazd, wycieczki[4].data_wyjazd, wycieczki[4].data_przyjazd, wycieczki[4].cel, wycieczki[4].opis, wycieczki[4].cena, new Data(13, 1, 2023), klienci[4]));

        klienci[4].wycieczki = addWycieczki(klienci[4], wycieczki[4]);

        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[5].czas_wyjazd, wycieczki[5].czas_przyjazd, wycieczki[5].data_wyjazd, wycieczki[5].data_przyjazd, wycieczki[5].cel, wycieczki[5].opis, wycieczki[5].cena, new Data(5, 1, 2023), klienci[5]));

        klienci[5].wycieczki = addWycieczki(klienci[5], wycieczki[5]);

        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[6].czas_wyjazd, wycieczki[6].czas_przyjazd, wycieczki[6].data_wyjazd, wycieczki[6].data_przyjazd, wycieczki[6].cel, wycieczki[6].opis, wycieczki[6].cena, new Data(1, 4, 2023), klienci[6]));

        klienci[6].wycieczki = addWycieczki(klienci[6], wycieczki[6]);

        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[1].czas_wyjazd, wycieczki[1].czas_przyjazd, wycieczki[1].data_wyjazd, wycieczki[1].data_przyjazd, wycieczki[1].cel, wycieczki[1].opis, wycieczki[1].cena, new Data(20, 1, 2023), klienci[7], wykupioneWycieczki[1].procentoweZapelnienie + .01F));

        klienci[7].wycieczki = addWycieczki(klienci[7], wycieczki[1]);

        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[2].czas_wyjazd, wycieczki[2].czas_przyjazd, wycieczki[2].data_wyjazd, wycieczki[2].data_przyjazd, wycieczki[2].cel, wycieczki[2].opis, wycieczki[2].cena, new Data(13, 6, 2023), klienci[8], wykupioneWycieczki[2].procentoweZapelnienie + 0.01F));

        klienci[8].wycieczki = addWycieczki(klienci[8], wycieczki[2]);

        wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[3].czas_wyjazd, wycieczki[3].czas_przyjazd, wycieczki[3].data_wyjazd, wycieczki[3].data_przyjazd, wycieczki[3].cel, wycieczki[3].opis, wycieczki[3].cena, new Data(9, 6, 2023), klienci[9], wykupioneWycieczki[3].procentoweZapelnienie + 0.01F));

        klienci[9].wycieczki = addWycieczki(klienci[9], wycieczki[3]);

        if(znizka(klienci[0], wycieczki[4].data_wyjazd, wycieczki[4].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[4].czas_wyjazd, wycieczki[4].czas_przyjazd, wycieczki[4].data_wyjazd, wycieczki[4].data_przyjazd, wycieczki[4].cel, wycieczki[4].opis, (int) (wycieczki[4].cena * .9), new Data(13, 1, 2023), klienci[0], wykupioneWycieczki[4].procentoweZapelnienie + 0.01F));

        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[4].czas_wyjazd, wycieczki[4].czas_przyjazd, wycieczki[4].data_wyjazd, wycieczki[4].data_przyjazd, wycieczki[4].cel, wycieczki[4].opis, wycieczki[4].cena, new Data(13, 1, 2023), klienci[0], wykupioneWycieczki[4].procentoweZapelnienie + 0.01F));

        klienci[0].wycieczki = addWycieczki(klienci[0], wycieczki[4]);

        if(znizka(klienci[1], wycieczki[5].data_wyjazd, wycieczki[5].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[5].czas_wyjazd, wycieczki[5].czas_przyjazd, wycieczki[5].data_wyjazd, wycieczki[5].data_przyjazd, wycieczki[5].cel, wycieczki[5].opis, (int) (wycieczki[5].cena * .9), new Data(3, 1, 2023), klienci[1], wykupioneWycieczki[5].procentoweZapelnienie + 0.01f));

        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[5].czas_wyjazd, wycieczki[5].czas_przyjazd, wycieczki[5].data_wyjazd, wycieczki[5].data_przyjazd, wycieczki[5].cel, wycieczki[5].opis, wycieczki[5].cena, new Data(3, 1, 2023), klienci[1], wykupioneWycieczki[5].procentoweZapelnienie + 0.01f));

        klienci[1].wycieczki = addWycieczki(klienci[1], wycieczki[5]);

        if(znizka(klienci[2], wycieczki[6].data_wyjazd, wycieczki[6].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[6].czas_wyjazd, wycieczki[6].czas_przyjazd, wycieczki[6].data_wyjazd, wycieczki[6].data_przyjazd, wycieczki[6].cel, wycieczki[6].opis, (int) (wycieczki[6].cena * .9), new Data(3, 4, 2023), klienci[2], wykupioneWycieczki[6].procentoweZapelnienie + 0.01f));

        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[6].czas_wyjazd, wycieczki[6].czas_przyjazd, wycieczki[6].data_wyjazd, wycieczki[6].data_przyjazd, wycieczki[6].cel, wycieczki[6].opis, wycieczki[6].cena, new Data(3, 4, 2023), klienci[2], wykupioneWycieczki[6].procentoweZapelnienie + 0.01f));

        klienci[2].wycieczki = addWycieczki(klienci[2], wycieczki[6]);

        if(znizka(klienci[3], wycieczki[0].data_wyjazd, wycieczki[0].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[0].czas_wyjazd, wycieczki[0].czas_przyjazd, wycieczki[0].data_wyjazd, wycieczki[0].data_przyjazd, wycieczki[0].cel, wycieczki[0].opis, (int) (wycieczki[0].cena * .9), new Data(20, 1, 2023), klienci[3], wykupioneWycieczki[0].procentoweZapelnienie + 0.01F));

        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[0].czas_wyjazd, wycieczki[0].czas_przyjazd, wycieczki[0].data_wyjazd, wycieczki[0].data_przyjazd, wycieczki[0].cel, wycieczki[0].opis, wycieczki[0].cena, new Data(20, 1, 2023), klienci[3], wykupioneWycieczki[0].procentoweZapelnienie + 0.01F));

        klienci[3].wycieczki = addWycieczki(klienci[3], wycieczki[0]);

        if(znizka(klienci[1], wycieczki[6].data_wyjazd, wycieczki[6].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[6].czas_wyjazd, wycieczki[6].czas_przyjazd, wycieczki[6].data_wyjazd, wycieczki[6].data_przyjazd, wycieczki[6].cel, wycieczki[6].opis, (int) (wycieczki[6].cena * .9), new Data(2, 4, 2023), klienci[1], wykupioneWycieczki[12].procentoweZapelnienie + 0.01f));

        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[6].czas_wyjazd, wycieczki[6].czas_przyjazd, wycieczki[6].data_wyjazd, wycieczki[6].data_przyjazd, wycieczki[6].cel, wycieczki[6].opis, wycieczki[6].cena, new Data(2, 4, 2023), klienci[1], wykupioneWycieczki[12].procentoweZapelnienie + 0.01f));

        klienci[1].wycieczki = addWycieczki(klienci[1], wycieczki[6]);

        if(znizka(klienci[2], wycieczki[5].data_wyjazd, wycieczki[5].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[5].czas_wyjazd, wycieczki[5].czas_przyjazd, wycieczki[5].data_wyjazd, wycieczki[5].data_przyjazd, wycieczki[5].cel, wycieczki[5].opis, (int) (wycieczki[5].cena * .9), new Data(2, 1, 2023), klienci[2], wykupioneWycieczki[11].procentoweZapelnienie + 0.01f));

        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[5].czas_wyjazd, wycieczki[5].czas_przyjazd, wycieczki[5].data_wyjazd, wycieczki[5].data_przyjazd, wycieczki[5].cel, wycieczki[5].opis, wycieczki[5].cena, new Data(2, 1, 2023), klienci[2], wykupioneWycieczki[11].procentoweZapelnienie + 0.01f));

        klienci[2].wycieczki = addWycieczki(klienci[2], wycieczki[5]);

        if(znizka(klienci[3], wycieczki[4].data_wyjazd, wycieczki[4].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[4].czas_wyjazd, wycieczki[4].czas_przyjazd, wycieczki[4].data_wyjazd, wycieczki[4].data_przyjazd, wycieczki[4].cel, wycieczki[4].opis, (int) (wycieczki[4].cena * .9), new Data(28, 1, 2023), klienci[3], wykupioneWycieczki[10].procentoweZapelnienie + 0.01f));

        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[4].czas_wyjazd, wycieczki[4].czas_przyjazd, wycieczki[4].data_wyjazd, wycieczki[4].data_przyjazd, wycieczki[4].cel, wycieczki[4].opis, wycieczki[4].cena, new Data(28, 1, 2023), klienci[3], wykupioneWycieczki[10].procentoweZapelnienie + 0.01f));

        klienci[3].wycieczki = addWycieczki(klienci[3], wycieczki[4]);

        if(znizka(klienci[6], wycieczki[1].data_wyjazd, wycieczki[1].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[1].czas_wyjazd, wycieczki[1].czas_przyjazd, wycieczki[1].data_wyjazd, wycieczki[1].data_przyjazd, wycieczki[1].cel, wycieczki[1].opis, (int) (wycieczki[1].cena * .9), new Data(11, 1, 2023), klienci[6], wykupioneWycieczki[7].procentoweZapelnienie + 0.01f));

        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[1].czas_wyjazd, wycieczki[1].czas_przyjazd, wycieczki[1].data_wyjazd, wycieczki[1].data_przyjazd, wycieczki[1].cel, wycieczki[1].opis, wycieczki[1].cena, new Data(11, 1, 2023), klienci[6], wykupioneWycieczki[7].procentoweZapelnienie + 0.01f));

        klienci[6].wycieczki = addWycieczki(klienci[6], wycieczki[1]);

        if(znizka(klienci[5], wycieczki[1].data_wyjazd, wycieczki[1].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[1].czas_wyjazd, wycieczki[1].czas_przyjazd, wycieczki[1].data_wyjazd, wycieczki[1].data_przyjazd, wycieczki[1].cel, wycieczki[1].opis, (int) (wycieczki[1].cena * .9), new Data(9, 1, 2023), klienci[5], wykupioneWycieczki[17].procentoweZapelnienie + 0.01f));
        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[1].czas_wyjazd, wycieczki[1].czas_przyjazd, wycieczki[1].data_wyjazd, wycieczki[1].data_przyjazd, wycieczki[1].cel, wycieczki[1].opis, wycieczki[1].cena, new Data(9, 1, 2023), klienci[5], wykupioneWycieczki[17].procentoweZapelnienie + 0.01f));

        klienci[5].wycieczki = addWycieczki(klienci[5], wycieczki[1]);

        if(znizka(klienci[9], wycieczki[2].data_wyjazd, wycieczki[2].data_przyjazd))
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[2].czas_wyjazd, wycieczki[2].czas_przyjazd, wycieczki[2].data_wyjazd, wycieczki[2].data_przyjazd, wycieczki[2].cel, wycieczki[2].opis, (int) (wycieczki[2].cena * .9), new Data(9, 1, 2023), klienci[9], wykupioneWycieczki[8].procentoweZapelnienie + 0.01f));

        else
            wykupioneWycieczki = add(wykupioneWycieczki, wykupioneWycieczki.length, new WykupionaWycieczka(wycieczki[2].czas_wyjazd, wycieczki[2].czas_przyjazd, wycieczki[2].data_wyjazd, wycieczki[2].data_przyjazd, wycieczki[2].cel, wycieczki[2].opis, wycieczki[2].cena, new Data(9, 1, 2023), klienci[9], wykupioneWycieczki[8].procentoweZapelnienie + 0.01f));

        klienci[9].wycieczki = addWycieczki(klienci[9], wycieczki[2]);

        return wykupioneWycieczki;
    }

    public static boolean znizka(Klient k, Data data_wyjazdu, Data data_przyjazdu)
    {
        int dni1 = k.odjazd.LiczbaDni();
        int dni2 = k.przyjazd.LiczbaDni();

        return data_wyjazdu.LiczbaDni() - dni1 < 30 || data_wyjazdu.LiczbaDni() - dni2 < 30 ||
                data_przyjazdu.LiczbaDni() - dni1 < 30 || data_przyjazdu.LiczbaDni() - dni2 < 30;
    }

    public static Klient[] add(Klient[] klienci, int n, Klient klient)
    {
        Klient[] newArr = new Klient[n+1];

        for(int i = 0; i < n; ++i)
            newArr[i] = klienci[i];

        newArr[n] = klient;

        return newArr;
    }

    public static Wycieczka[] add(Wycieczka[] wycieczki, int n, Wycieczka wycieczka)
    {
        Wycieczka[] newArr= new Wycieczka[n + 1];

        for(int i = 0; i < n; ++i)
            newArr[i] = wycieczki[i];

        newArr[n] = wycieczka;

        return newArr;
    }

    public static WykupionaWycieczka[] add(WykupionaWycieczka[] wykupioneWycieczki, int n , WykupionaWycieczka wykupionaWycieczka)
    {
        WykupionaWycieczka[] newArr= new WykupionaWycieczka[n + 1];

        for(int i = 0; i < n; ++i)
            newArr[i] = wykupioneWycieczki[i];

        newArr[n] = wykupionaWycieczka;

        return newArr;
    }
}