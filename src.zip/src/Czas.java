
public class Czas {

    private int godz;   //godziny
    private int min;    //minuty
    private int sek;    //sekundy

    public Czas(int godz, int min)
    {
        this.godz = godz;
        this.min = min;
    }

    public Czas(int godzina, int minuta, int sekunda) {
        this.godz = godzina;
        this.min = minuta;
        this.sek = sekunda;
    }
    public Czas(Czas czas)
    {
        this.godz = czas.godz;
        this.min = czas.min;
        this.sek = czas.sek;
    }

    @Override
    public String toString()
    {
        if(min < 10)
            return godz + ":0" + min;
        else
            return godz + ":" + min;
    }

}
