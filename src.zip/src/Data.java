public class Data {
    private int dzien;  //dzien
    private int miesiac;    //miesiac
    private int rok;    //rok

    public Data(int dzien, int miesiac, int rok) {
        this.dzien = dzien;
        this.miesiac = miesiac;
        this.rok = rok;
    }

    public Data(Data data) {
        this.dzien = data.dzien;
        this.miesiac = data.miesiac;
        this.rok = data.rok;
    }

    public int LiczbaDni() {
        int dni = dzien;
        int dniLuty = obliczLuty(rok);
        int[] ilDni = {31, dniLuty, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        for (int i = miesiac - 1; i > 0; --i) {
            dni += ilDni[i - 1];
        }

        for (int i = rok - 1; i > 0; --i) {
            dni += (i % 400 == 0 || (i % 4 == 0 && i % 100 != 0)) ? 366 : 365;
        }

        return dni;
    }

    private int obliczLuty(int rok) {
        if (rok % 400 == 0 || (rok % 4 == 0 && rok % 100 != 0)) {
            return 29;
        } else {
            return 28;
        }
    }


    public String toString() {
        if (miesiac < 10)
            return dzien + ":0" + miesiac + ":" + rok;
        else
            return dzien + ":" + miesiac + ":" + rok;
    }
}
