public class WykupionaWycieczka {
    public Czas czas_wyjazd;
    public Czas czas_przyjazd;
    public Data data_wyjazd;
    public Data data_przyjazd;
    public String cel;
    public String opis;
    public int cena;
    public Data dataZakupu;
    public Klient klient;
    public float procentoweZapelnienie;

    public static int iloscWycieczek = 0;

    public WykupionaWycieczka(Czas czas_wyjazd, Czas czas_przyjazd, Data data_wyjazd, Data data_przyjazd, String cel, String opis, int cena, Data dataZakupu, Klient klient)
    {
        this.czas_wyjazd = czas_wyjazd;
        this.czas_przyjazd = czas_przyjazd;
        this.data_wyjazd = data_wyjazd;
        this.data_przyjazd = data_przyjazd;
        this.cel = cel;
        this.opis = opis;
        this.cena = cena;
        this.dataZakupu = dataZakupu;
        this.klient = klient;

        this.procentoweZapelnienie = 0.01f;

        klient.odjazd = data_wyjazd;
        klient.przyjazd = data_przyjazd;

        iloscWycieczek++;
    }

    public WykupionaWycieczka(Czas czas_wyjazd, Czas czas_przyjazd, Data data_wyjazd, Data data_przyjazd, String cel, String opis, int cena, Data dataZakupu, Klient klient, float procentoweZapelnienie)
    {
        this.czas_wyjazd = czas_wyjazd;
        this.czas_przyjazd = czas_przyjazd;
        this.data_wyjazd = data_wyjazd;
        this.data_przyjazd = data_przyjazd;
        this.cel = cel;
        this.opis = opis;
        this.cena = cena;
        this.dataZakupu = dataZakupu;
        this.klient = klient;
        this.procentoweZapelnienie = procentoweZapelnienie;

        klient.odjazd = data_wyjazd;
        klient.przyjazd = data_przyjazd;

        iloscWycieczek++;
    }

    public WykupionaWycieczka(WykupionaWycieczka wykupionaWycieczka)
    {
        this.czas_wyjazd = wykupionaWycieczka.czas_wyjazd;
        this.czas_przyjazd = wykupionaWycieczka.czas_przyjazd;
        this.data_wyjazd = wykupionaWycieczka.data_wyjazd;
        this.data_przyjazd =wykupionaWycieczka.data_przyjazd;
        this.cel = wykupionaWycieczka.cel;
        this.opis = wykupionaWycieczka.opis;
        this.cena = wykupionaWycieczka.cena;
        this.dataZakupu = wykupionaWycieczka.dataZakupu;
        this.klient = wykupionaWycieczka.klient;
        this.procentoweZapelnienie = wykupionaWycieczka.procentoweZapelnienie;
        this.klient.odjazd = wykupionaWycieczka.data_wyjazd;
        this.klient.przyjazd = wykupionaWycieczka.data_przyjazd;
        iloscWycieczek++;

    }

    @Override
    public String toString()
    {
        return"|| Wyjazd: " + data_wyjazd + " | Powrót: " + data_przyjazd + " | Cel: " + cel + " | Opis: " + opis + " | Cena: " + cena + " zł | Dane klienta: " + klient + " | Procentowe zapełnienie środka transportu: " + procentoweZapelnienie * 100 + " % | Czas wyjazdu: " + czas_wyjazd + " | Czas powrotu: " + czas_przyjazd + " ||";
    }

}
