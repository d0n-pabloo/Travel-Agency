
public class Wycieczka {
    Czas czas_wyjazd;
    Czas czas_przyjazd;
    Data data_wyjazd;
    Data data_przyjazd;
    public String cel;
    public String opis;
    public int cena;
    public int ilosc_m;
    public Wycieczka(Data data_wyjazd, Data data_przyjazd, String cel, String opis,
                     int cena, int ilosc_m, Czas czas_wyjazd, Czas czas_przyjazd)
    {
        this.data_wyjazd = data_wyjazd;
        this.data_przyjazd = data_przyjazd;
        this.cel = cel;
        this.opis = opis;
        this.cena = cena;
        this.ilosc_m = ilosc_m;
        this.czas_wyjazd = czas_wyjazd;
        this.czas_przyjazd = czas_przyjazd;
        }

    public Wycieczka(Wycieczka wycieczka)
    {
        this.data_wyjazd = wycieczka.data_wyjazd;
        this.data_przyjazd = wycieczka.data_przyjazd;
        this.cel = wycieczka.cel;
        this.opis = wycieczka.opis;
        this.cena = wycieczka.cena;
        this.ilosc_m = wycieczka.ilosc_m;
        this.czas_wyjazd = wycieczka.czas_wyjazd;
        this.czas_przyjazd = wycieczka.czas_przyjazd;

    }

    @Override
    public String toString()
    {
        return "|-| Wyjazd: " + data_wyjazd + " | Powrót: " + data_przyjazd + " | Cel: " + cel
                + " | Opis: " + opis + " | Cena: " + cena + " zł | Ilość miejsc: " + ilosc_m + " | Czas wyjazdu: " + czas_wyjazd
                + " | Czas powrotu: " + czas_przyjazd + " |-|";
    }
}
