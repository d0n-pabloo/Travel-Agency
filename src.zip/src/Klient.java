public class Klient {
    public String imie;
    private String nazwisko;
    private int wiek;
    private String adres;
    public Data przyjazd;
    public Data odjazd;
    public Wycieczka[] wycieczki = {};

    public Klient(String imie, String nazwisko, int wiek, String adres) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.wiek = wiek;
        this.adres = adres;
    }

    public Klient(Klient klient) {
        this.imie = klient.imie;
        this.nazwisko = klient.nazwisko;
        this.wiek = klient.wiek;
        this.adres = klient.adres;

        this.wycieczki = klient.wycieczki;
    }

    public String toString() {
        return "| Imie: " + imie + " | Nazwisko: " + nazwisko + " | Wiek: " + wiek + " | Adres: " + adres + " | ";
    }

    public Wycieczka[] add(Wycieczka wycieczka){
        Wycieczka[] newArray= new Wycieczka[wycieczki.length + 1];

        for(int i = 0; i < wycieczki.length + 1; ++i)
            newArray[i] = wycieczki[i];

        newArray[wycieczki.length + 1] = wycieczka;

        return newArray;
    }


    public void getWycieczka()
    {
        for(Wycieczka wycieczka: wycieczki) {
            System.out.println(wycieczka);
        }
    }


    public int getCena()
    {
        int suma = 0;
        for(Wycieczka wycieczka: wycieczki) {
            suma += wycieczka.cena;
        }

        return suma;
    }
}
